"""
-*- coding: utf-8 -*-
Data Preprocessing
Created on Tue Apr 30 2019
@author:
"""

import re # for regular expressions
import pandas as pd 
import numpy as np 

#%% reading in data
df = pd.read_csv('raw_tweets.csv', usecols = ['ID', 'text'])

#%% extract hashtags
def find_hashtags(text):
    #'''This function will extract hashtags'''
    return re.findall('(#[\w]*)', text)   

# find all hashtags and convert them to lower
df['hashtags'] = df.text.apply(find_hashtags)
df['hashtags'] = [[k.lower() for k in l] for l in df['hashtags']]

#%% Data cleaning
import nltk
#nltk.download()
from nltk.tokenize import RegexpTokenizer
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer 

def remove_links(tweet):
    '''Takes a string and removes web links from it'''
    tweet = re.sub(r'http\S+', '', tweet) # remove http links
    tweet = re.sub(r'bit.ly/\S+', '', tweet) # remove bitly links
    #tweet = tweet.strip('[link]') # remove [links]
    return tweet

def remove_users(tweet):
    '''Takes a string and removes retweet and @user information'''
    tweet = re.sub('(RT\s@[A-Za-z]+[A-Za-z0-9-_]+)', '', tweet) # remove retweet
    tweet = re.sub('(@[\w]*)', '', tweet) # remove tweeted @
    return tweet

def remove_emoji(tweet):
    emoji_pattern = re.compile("["
        u"\U0001F600-\U0001F64F"  # emoticons
        u"\U0001F300-\U0001F5FF"  # symbols & pictographs
        u"\U0001F680-\U0001F6FF"  # transport & map symbols
        u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                           "]+", flags=re.UNICODE)
    tweet = emoji_pattern.sub(r'', tweet) # no emoji
    return tweet
    
my_stopwords = nltk.corpus.stopwords.words('english')
my_stopwords.extend(['amp', 'rt'])
lemmatizer = WordNetLemmatizer() 

my_punctuation = '!“”"$%&\'()*+,-./:;<=>?[\\]^_`’{|}~•@'

# cleaning master function
def clean_tweet(tweet):
    tweet = remove_users(tweet)
    tweet = remove_links(tweet)
    tweet = re.sub(r"\\\w+", "", str(tweet)) # remove some encoding issues
    tweet = remove_emoji(tweet)
    tweet = re.sub('['+my_punctuation + ']+', ' ', tweet) # strip punctuation
    tweet = re.sub('([0-9]+)', '', tweet) # remove numbers
    tweet = tweet.lower() # lower case
    tweet_token_list = [word for word in tweet.split(' ')
                        if word not in my_stopwords] # remove stopwords
    # apply lemmatizer
    tweet_token_list = [lemmatizer.lemmatize(word,pos='n') if '#' not in word else word
                        for word in tweet_token_list]
    tweet_token_list = [lemmatizer.lemmatize(word,pos='v') if '#' not in word else word
                        for word in tweet_token_list]
    tweet = ' '.join([w for w in tweet_token_list if len(w)>1])
    tweet = re.sub('\s+', ' ', tweet) #remove double spacing
    return tweet

df['clean_tweet'] = df.text.apply(clean_tweet)

print(df.clean_tweet.head)

export_csv = df.to_csv(r'cleaned_tweets.csv', columns=['ID','hashtags','clean_tweet'], index=False, header=True, encoding='utf-8')
